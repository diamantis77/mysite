/**
 * PAPIGIÓN FOOTER
 * Design: Dark Premium Black & Deep Red Theme
 */

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-12 bg-[#000000] border-t border-[#2d2d2d]">
      <div className="container max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="text-center md:text-left">
            <div className="text-2xl font-bold text-white">
              Papigión
            </div>
            <div className="text-xs tracking-widest uppercase mt-1 text-[#c41e3a] font-bold">
              Premium Coffee Bar · Τύρναβος
            </div>
          </div>

          {/* Center: Thin rule */}
          <div className="hidden md:block h-px flex-1 max-w-xs bg-[#2d2d2d]" />

          {/* Right: Links */}
          <div className="flex flex-col items-center md:items-end gap-2">
            <div className="flex gap-6">
              {["ΑΡΧΙΚΗ", "ΜΕΝΟΥ", "GALLERY", "ΕΠΙΚΟΙΝΩΝΙΑ"].map((link, i) => {
                const hrefs = ["#home", "#menu", "#gallery", "#contact"];
                return (
                  <a
                    key={link}
                    href={hrefs[i]}
                    className="text-xs tracking-widest uppercase transition-colors duration-300 text-white/60 hover:text-[#c41e3a] font-semibold"
                  >
                    {link}
                  </a>
                );
              })}
            </div>
            <p className="text-xs text-white/40">
              © {currentYear} Papigión. Τύρναβος, Ελλάδα.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
