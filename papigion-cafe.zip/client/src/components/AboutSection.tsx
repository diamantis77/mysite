/**
 * PAPIGIÓN ABOUT SECTION
 * Design: Dark Premium Black & Deep Red Theme
 * Asymmetric two-column layout with dark background and red accents
 */

import { useEffect, useRef, useState } from "react";

const ABOUT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/papigion_about_bg-BH897tBtWFZmcrSntvxNos.webp";
const OUTDOOR_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_espresso_outdoor_d45f598d.webp";

function useInView(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);

  return { ref, inView };
}

export default function AboutSection() {
  const { ref, inView } = useInView(0.15);

  return (
    <section id="about" className="py-24 md:py-36 overflow-hidden bg-[#0f0f0f]">
      <div className="container max-w-7xl mx-auto px-4" ref={ref}>
        {/* Section label */}
        <div
          className="flex items-center gap-4 mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.7s ease-out",
          }}
        >
          <div className="h-px flex-1 max-w-12 bg-[#c41e3a]" />
          <span className="text-xs tracking-widest uppercase text-[#c41e3a] font-bold">
            Σχετικά με εμάς
          </span>
        </div>

        {/* Two-column layout */}
        <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-center">
          {/* Left: Images */}
          <div
            className="relative"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(-40px)",
              transition: "all 0.9s ease-out 0.1s",
            }}
          >
            {/* Main image */}
            <div className="relative overflow-hidden border border-[#2d2d2d]" style={{ paddingBottom: "120%" }}>
              <img
                src={ABOUT_IMG}
                alt="Artisan coffee preparation at Papigión"
                className="absolute inset-0 w-full h-full object-cover"
                style={{ objectPosition: "center" }}
              />
            </div>
            {/* Floating accent image */}
            <div
              className="absolute -bottom-8 -right-6 md:-right-10 w-2/5 overflow-hidden shadow-2xl border-4 border-[#1a1a1a]"
            >
              <div className="relative" style={{ paddingBottom: "130%" }}>
                <img
                  src={OUTDOOR_IMG}
                  alt="Outdoor seating at Papigión"
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Right: Text */}
          <div
            className="md:pl-8"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(40px)",
              transition: "all 0.9s ease-out 0.25s",
            }}
          >
            <h2 className="text-5xl md:text-6xl font-bold leading-tight mb-8 text-white">
              Ένας χώρος που{" "}
              <span className="text-[#c41e3a]">αγαπάς</span>{" "}
              να επιστρέφεις
            </h2>

            <div className="h-px mb-8 bg-[#2d2d2d]" />

            <p className="text-lg leading-relaxed mb-6 text-white/80">
              Το Papigión είναι το premium coffee bar του Τυρνάβου — ένας χώρος όπου ο εξαιρετικός καφές
              συναντά την ζεστή ατμόσφαιρα. Από το πρωινό espresso μέχρι το βραδινό cocktail,
              κάθε στιγμή εδώ είναι μοναδική.
            </p>

            <p className="text-lg leading-relaxed mb-10 text-white/80">
              Με βαθμολογία <strong className="text-[#c41e3a]">4.8/5</strong> από 193 κριτικές, η ποιότητα μας μιλά από μόνη της.
              Dine-in, takeaway ή delivery — εμείς είμαστε εδώ για σένα, ανοιχτά μέχρι τις 2 π.μ.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              {[
                { number: "4.8", label: "Βαθμολογία" },
                { number: "193", label: "Κριτικές" },
                { number: "2 π.μ.", label: "Κλείνουμε" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-4xl font-bold text-[#c41e3a] mb-2">
                    {stat.number}
                  </div>
                  <div className="text-xs tracking-widest uppercase text-white/60 font-semibold">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
