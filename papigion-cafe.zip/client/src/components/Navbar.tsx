/**
 * PAPIGIÓN NAVBAR
 * Design: Dark Premium Black & Deep Red Theme
 * Logo with bowtie symbol, red gamma accent, navigation
 */

import { useState } from "react";
import { Menu, X } from "lucide-react";

interface NavbarProps {
  scrolled: boolean;
}

const navLinks = [
  { label: "ΑΡΧΙΚΗ", href: "#home" },
  { label: "ΣΧΕΤΙΚΑ", href: "#about" },
  { label: "GALLERY", href: "#gallery" },
  { label: "ΜΕΝΟΥ", href: "#menu" },
  { label: "ΕΠΙΚΟΙΝΩΝΙΑ", href: "#contact" },
];

export default function Navbar({ scrolled }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <nav
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
        style={{
          backgroundColor: scrolled ? "rgba(15, 15, 15, 0.98)" : "rgba(15, 15, 15, 0.9)",
          backdropFilter: "blur(12px)",
          borderBottom: scrolled ? "1px solid rgba(196, 30, 58, 0.3)" : "1px solid rgba(45, 45, 45, 0.5)",
          boxShadow: scrolled ? "0 4px 30px rgba(196, 30, 58, 0.1)" : "none",
        }}
      >
        <div className="container max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <button
              onClick={() => handleNavClick("#home")}
              className="flex items-center gap-2 group"
            >
              <div className="flex flex-col items-center">
                {/* Bowtie Symbol */}
                <svg
                  width="28"
                  height="20"
                  viewBox="0 0 32 24"
                  className="mb-1"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  {/* Left bowtie wing */}
                  <path
                    d="M8 8L2 12L8 16V8Z"
                    fill="#c41e3a"
                    className="transition-all duration-300 group-hover:fill-white"
                  />
                  {/* Right bowtie wing */}
                  <path
                    d="M24 8L30 12L24 16V8Z"
                    fill="#c41e3a"
                    className="transition-all duration-300 group-hover:fill-white"
                  />
                  {/* Center white diamond */}
                  <polygon points="16,10 18,12 16,14 14,12" fill="white" />
                </svg>
                {/* Brand Name with Red Gamma */}
                <div className="flex items-baseline gap-0 text-xs font-bold tracking-widest">
                  <span className="text-white">παπι</span>
                  <span className="text-[#c41e3a] text-sm font-bold">γ</span>
                  <span className="text-white">ιόν</span>
                </div>
              </div>
            </button>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="relative text-xs font-semibold tracking-widest uppercase transition-all duration-300 group text-white/70 hover:text-[#c41e3a]"
                >
                  {link.label}
                  <span className="absolute -bottom-1 left-0 h-px w-0 transition-all duration-300 group-hover:w-full bg-[#c41e3a]" />
                </button>
              ))}
              <a
                href="tel:+302492025059"
                className="text-xs font-bold tracking-widest uppercase px-5 py-2.5 transition-all duration-300 bg-[#c41e3a] text-white hover:bg-[#a01830] rounded"
              >
                ΠΑΡΑΓΓΕΙΛΕ
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 transition-all duration-300 hover:text-[#c41e3a] text-white"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 flex flex-col pt-20 bg-[#0f0f0f] border-t border-[#2d2d2d]">
          <div className="container space-y-1 pt-8">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="text-left py-4 text-lg font-semibold border-b border-[#2d2d2d] transition-all duration-300 text-white/70 hover:text-[#c41e3a] hover:pl-4"
              >
                {link.label}
              </button>
            ))}
            <a
              href="tel:+302492025059"
              className="mt-6 block text-center text-sm font-bold tracking-widest uppercase py-4 transition-all duration-300 bg-[#c41e3a] text-white hover:bg-[#a01830] rounded"
            >
              📞 ΚΆΛΕΣΕ
            </a>
          </div>
        </div>
      )}
    </>
  );
}
