/**
 * PAPIGIÓN GALLERY SECTION
 * Design: Dark Premium Black & Deep Red Theme
 * Masonry-style grid with lightbox
 */

import { useEffect, useRef, useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

const galleryImages = [
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_hero_2aed8588.webp",
    alt: "Papigión outdoor seating with coffee",
    category: "Χώρος",
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_drinks_outdoor_45cff6ed.webp",
    alt: "Drinks at Papigión outdoor terrace",
    category: "Ροφήματα",
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_interior_seating_011948eb.webp",
    alt: "Interior seating area",
    category: "Χώρος",
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_cocktail_mule_2acdcd78.webp",
    alt: "Cocktail Gin Mule at Papigión",
    category: "Cocktails",
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_espresso_outdoor_d45f598d.webp",
    alt: "Espresso outdoor at Papigión",
    category: "Καφές",
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_freddo_coffee_f5cc9c80.webp",
    alt: "Freddo coffee at Papigión",
    category: "Καφές",
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_night_drinks_34f9b13f.webp",
    alt: "Night drinks at Papigión",
    category: "Βράδυ",
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_storefront_e4ae538f.webp",
    alt: "Papigión storefront",
    category: "Χώρος",
  },
];

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, inView };
}

export default function GallerySection() {
  const { ref, inView } = useInView(0.1);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const openLightbox = (index: number) => setLightboxIndex(index);
  const closeLightbox = () => setLightboxIndex(null);
  const prevImage = () => setLightboxIndex(i => i !== null ? (i - 1 + galleryImages.length) % galleryImages.length : null);
  const nextImage = () => setLightboxIndex(i => i !== null ? (i + 1) % galleryImages.length : null);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowLeft") prevImage();
      if (e.key === "ArrowRight") nextImage();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [lightboxIndex]);

  return (
    <section id="gallery" className="py-24 md:py-36 overflow-hidden bg-[#0f0f0f]">
      <div className="container max-w-7xl mx-auto px-4" ref={ref}>
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
          <div
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateY(0)" : "translateY(20px)",
              transition: "all 0.7s ease-out",
            }}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="h-px w-10 bg-[#c41e3a]" />
              <span className="text-xs tracking-widest uppercase text-[#c41e3a] font-bold">
                Gallery
              </span>
            </div>
            <h2 className="text-5xl md:text-6xl font-bold text-white">
              Ζήσε την εμπειρία
            </h2>
          </div>
          <p
            className="mt-4 md:mt-0 max-w-xs text-white/60 text-sm leading-relaxed"
            style={{
              opacity: inView ? 1 : 0,
              transition: "all 0.7s ease-out 0.2s",
            }}
          >
            Κλικ σε κάθε φωτογραφία για μεγέθυνση
          </p>
        </div>

        {/* Masonry Grid */}
        <div className="columns-2 md:columns-3 lg:columns-4 gap-3 space-y-3">
          {galleryImages.map((img, i) => (
            <div
              key={i}
              className="break-inside-avoid relative overflow-hidden group cursor-pointer border border-[#2d2d2d] hover:border-[#c41e3a] transition-all duration-300"
              onClick={() => openLightbox(i)}
              style={{
                opacity: inView ? 1 : 0,
                transform: inView ? "translateY(0)" : "translateY(30px)",
                transition: `all 0.7s ease-out ${0.05 * i}s`,
              }}
            >
              <img
                src={img.src}
                alt={img.alt}
                className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              {/* Hover overlay */}
              <div className="absolute inset-0 flex items-end p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-t from-black/80 to-transparent">
                <span className="text-xs tracking-widest uppercase text-[#c41e3a] font-bold">
                  {img.category}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/95"
          onClick={closeLightbox}
        >
          <button
            className="absolute top-6 right-6 p-2 transition-all hover:text-[#c41e3a] text-white"
            onClick={closeLightbox}
          >
            <X size={28} />
          </button>
          <button
            className="absolute left-4 md:left-8 p-3 transition-all hover:text-[#c41e3a] text-white"
            onClick={(e) => { e.stopPropagation(); prevImage(); }}
          >
            <ChevronLeft size={32} />
          </button>
          <div
            className="max-w-4xl max-h-[85vh] mx-16"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={galleryImages[lightboxIndex].src}
              alt={galleryImages[lightboxIndex].alt}
              className="max-w-full max-h-[85vh] object-contain"
            />
            <p className="text-center mt-4 text-xs tracking-widest uppercase text-[#c41e3a] font-bold">
              {galleryImages[lightboxIndex].category}
            </p>
          </div>
          <button
            className="absolute right-4 md:right-8 p-3 transition-all hover:text-[#c41e3a] text-white"
            onClick={(e) => { e.stopPropagation(); nextImage(); }}
          >
            <ChevronRight size={32} />
          </button>
        </div>
      )}
    </section>
  );
}
