/**
 * PAPIGIÓN QUOTE SECTION
 * Design: Parisian Minimal Noir — full-width photo with quote overlay
 * Uses a real Papigion photo as background
 */

import { useEffect, useRef, useState } from "react";

const QUOTE_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/photo_night_drinks_34f9b13f.webp";

function useInView(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, inView };
}

export default function QuoteSection() {
  const { ref, inView } = useInView(0.2);

  return (
    <section className="relative py-32 md:py-48 overflow-hidden" style={{ backgroundColor: "#1C1916" }}>
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${QUOTE_BG})`,
          filter: "brightness(0.35)",
        }}
      />

      {/* Content */}
      <div className="relative z-10 container text-center" ref={ref}>
        {/* Decorative line */}
        <div
          className="flex items-center justify-center gap-4 mb-10"
          style={{
            opacity: inView ? 1 : 0,
            transition: "all 0.8s ease-out",
          }}
        >
          <div className="h-px w-16" style={{ backgroundColor: "#C8962E" }} />
          <span style={{ color: "#C8962E", fontSize: "0.8rem" }}>◆</span>
          <div className="h-px w-16" style={{ backgroundColor: "#C8962E" }} />
        </div>

        {/* Quote */}
        <blockquote
          className="font-display font-light italic max-w-3xl mx-auto mb-8"
          style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: "clamp(1.5rem, 4vw, 2.5rem)",
            color: "#FAF7F2",
            lineHeight: "1.5",
            letterSpacing: "0.01em",
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(25px)",
            transition: "all 0.9s ease-out 0.15s",
          }}
        >
          "Κάθε φλιτζάνι καφέ είναι μια μικρή τελετή — μια στιγμή που ανήκει μόνο σε σένα."
        </blockquote>

        {/* Attribution */}
        <div
          className="flex items-center justify-center gap-3"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(15px)",
            transition: "all 0.8s ease-out 0.3s",
          }}
        >
          <div className="h-px w-8" style={{ backgroundColor: "#C8962E" }} />
          <span
            className="font-label text-xs tracking-widest uppercase"
            style={{
              fontFamily: "'Montserrat', sans-serif",
              fontSize: "0.65rem",
              letterSpacing: "0.2em",
              color: "#C8962E",
            }}
          >
            Papigión Coffee Bar
          </span>
          <div className="h-px w-8" style={{ backgroundColor: "#C8962E" }} />
        </div>
      </div>
    </section>
  );
}
