/**
 * PAPIGIÓN HERO SECTION
 * Design: Dark Premium Black & Deep Red Theme
 * Large bowtie logo, brand name with red gamma, CTA buttons
 */

import { useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/papigion_hero_dark-WUKXAXb48tD5VFSBLpaxwE.webp";

export default function HeroSection() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-[10s] ease-out"
        style={{
          backgroundImage: `url(${HERO_BG})`,
          transform: visible ? "scale(1.03)" : "scale(1.08)",
        }}
      />

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/65" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
        {/* Large Bowtie Logo */}
        <svg
          width="140"
          height="120"
          viewBox="0 0 32 24"
          className="mx-auto mb-8"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "scale(1)" : "scale(0.8)",
            transition: "all 0.9s ease-out 0.2s",
          }}
        >
          {/* Left bowtie wing */}
          <path d="M8 8L2 12L8 16V8Z" fill="#c41e3a" />
          {/* Right bowtie wing */}
          <path d="M24 8L30 12L24 16V8Z" fill="#c41e3a" />
          {/* Center white diamond */}
          <polygon points="16,10 18,12 16,14 14,12" fill="white" />
        </svg>

        {/* Brand Name with Red Gamma */}
        <h1
          className="text-7xl md:text-8xl font-bold tracking-tight mb-4"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.9s ease-out 0.35s",
          }}
        >
          <span className="text-white">παπι</span>
          <span className="text-[#c41e3a]">γ</span>
          <span className="text-white">ιόν</span>
        </h1>

        {/* Tagline */}
        <p
          className="text-white/80 text-lg md:text-2xl font-light mb-2"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(25px)",
            transition: "all 0.9s ease-out 0.5s",
          }}
        >
          ALL DAY COFFEE BAR
        </p>

        {/* Subtitle */}
        <p
          className="text-white/60 text-sm md:text-base mb-12 max-w-2xl mx-auto"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.8s ease-out 0.6s",
          }}
        >
          Ο καφές σου, η στιγμή σου. Premium coffee experience στον Τύρναβο.
        </p>

        {/* Rating */}
        <div
          className="flex items-center justify-center gap-3 mb-12"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.8s ease-out 0.65s",
          }}
        >
          <div className="flex gap-1">
            {[...Array(5)].map((_, i) => (
              <span key={i} className="text-[#c41e3a] text-xl">
                ★
              </span>
            ))}
          </div>
          <span className="text-white/70 text-sm">
            4.8 · 193 κριτικές
          </span>
        </div>

        {/* CTA Buttons */}
        <div
          className="flex flex-col md:flex-row gap-4 justify-center"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.8s ease-out 0.8s",
          }}
        >
          <a
            href="tel:+302492025059"
            className="px-8 py-4 bg-[#c41e3a] text-white font-bold text-lg rounded hover:bg-[#a01830] transition-all duration-300 shadow-lg hover:shadow-[0_0_30px_rgba(196,30,58,0.4)] hover:scale-105"
          >
            📞 ΠΑΡΑΓΓΕΙΛΕ ΤΩΡΑ
          </a>
          <a
            href="#menu"
            className="px-8 py-4 border-2 border-white text-white font-bold text-lg rounded hover:bg-white/10 transition-all duration-300"
          >
            ΔΕΣ ΤΟ ΜΕΝΟΥ
          </a>
        </div>

        {/* Scroll Indicator */}
        <button
          onClick={() => document.querySelector("#about")?.scrollIntoView({ behavior: "smooth" })}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-2 opacity-60 hover:opacity-100 transition-opacity duration-300"
        >
          <span className="text-xs tracking-widest uppercase text-white/60">Scroll</span>
          <ChevronDown size={20} className="text-white animate-bounce" />
        </button>
      </div>
    </section>
  );
}
