/**
 * PAPIGIÓN MENU SECTION
 * Design: Dark Premium Black & Deep Red Theme
 * Tabbed categories, elegant cards with red accents
 */

import { useEffect, useRef, useState } from "react";

const menuCategories = [
  {
    id: "coffee",
    label: "Καφέδες",
    icon: "☕",
    items: [
      { name: "Espresso", description: "Μονό ή διπλό, αρωματικό και πλούσιο", price: "1.50", img: null },
      { name: "Freddo Espresso", description: "Παγωμένος espresso, δροσερός και έντονος", price: "2.50", img: null },
      { name: "Freddo Cappuccino", description: "Espresso με παγωμένο αφρόγαλα", price: "2.80", img: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/menu_freddo_cappuccino_d76c698c.webp" },
      { name: "Cappuccino", description: "Ζεστό, κρεμώδες με αφρόγαλα", price: "2.80", img: null },
      { name: "Latte", description: "Μαλακός, γάλα με espresso", price: "3.00", img: null },
      { name: "Filter Coffee", description: "Αργής εκχύλισης, ήπιος και αρωματικός", price: "2.00", img: null },
    ],
  },
  {
    id: "drinks",
    label: "Ροφήματα",
    icon: "🥤",
    items: [
      { name: "Φρέσκος Χυμός Πορτοκάλι", description: "Φρεσκοστυμμένος, φυσικός", price: "2.50", img: null },
      { name: "Smoothie", description: "Φρούτα εποχής, γιαούρτι, μέλι", price: "3.50", img: null },
      { name: "Iced Tea", description: "Τσάι με πάγο, λεμόνι και μέντα", price: "2.50", img: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/menu_iced_coffee_e8ba4af2.webp" },
      { name: "Hot Chocolate", description: "Βελούδινη σοκολάτα με αφρόγαλα", price: "3.00", img: null },
      { name: "Milkshake", description: "Βανίλια, σοκολάτα ή φράουλα", price: "4.00", img: null },
    ],
  },
  {
    id: "cocktails",
    label: "Cocktails",
    icon: "🍸",
    items: [
      { name: "Cocktail Gin Mule", description: "Gin, ginger beer, lime — made by Theo", price: "5.00", img: null },
      { name: "Aperol Spritz", description: "Aperol, prosecco, soda, πορτοκάλι", price: "5.00", img: null },
      { name: "Mojito", description: "Rum, lime, μέντα, ζάχαρη, soda", price: "5.00", img: null },
      { name: "Cosmopolitan", description: "Vodka, triple sec, cranberry, lime", price: "5.50", img: null },
      { name: "Espresso Martini", description: "Vodka, espresso, coffee liqueur", price: "6.00", img: null },
    ],
  },
  {
    id: "food",
    label: "Φαγητό",
    icon: "🥞",
    items: [
      { name: "Pancakes Σοκολάτα Μπισκότο", description: "Fluffy pancakes με σοκολάτα και μπισκότο", price: "4.50", img: "https://d2xsxph8kpxj0f.cloudfront.net/310519663495418062/JNZusQqHQ2bSocBsMe8vK2/menu_pancakes_85270c7e.webp" },
      { name: "Toast", description: "Ψωμί ολικής, τυρί, ζαμπόν, ντομάτα", price: "3.50", img: null },
      { name: "Croissant Βουτύρου", description: "Φρέσκο, τραγανό, με βούτυρο ή μαρμελάδα", price: "2.50", img: null },
      { name: "Cheesecake", description: "Κρεμώδης, με coulis φράουλας", price: "4.00", img: null },
      { name: "Brownie", description: "Ζεστό brownie σοκολάτας με παγωτό", price: "4.00", img: null },
      { name: "Club Sandwich", description: "Κοτόπουλο, μπέικον, τυρί, λαχανικά", price: "5.50", img: null },
    ],
  },
];

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, inView };
}

export default function MenuSection() {
  const { ref, inView } = useInView(0.1);
  const [activeCategory, setActiveCategory] = useState("coffee");

  const currentCategory = menuCategories.find(c => c.id === activeCategory)!;

  return (
    <section id="menu" className="py-24 md:py-36 overflow-hidden bg-[#0f0f0f]">
      <div className="container max-w-7xl mx-auto px-4" ref={ref}>
        {/* Header */}
        <div
          className="text-center mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.7s ease-out",
          }}
        >
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-px w-12 bg-[#c41e3a]" />
            <span className="text-xs tracking-widest uppercase text-[#c41e3a] font-bold">
              Μενού
            </span>
            <div className="h-px w-12 bg-[#c41e3a]" />
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white">
            Ανακάλυψε τις γεύσεις μας
          </h2>
        </div>

        {/* Category Tabs */}
        <div
          className="flex flex-wrap justify-center gap-2 mb-12"
          style={{
            opacity: inView ? 1 : 0,
            transition: "all 0.7s ease-out 0.15s",
          }}
        >
          {menuCategories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className="flex items-center gap-2 px-6 py-3 text-xs tracking-widest uppercase transition-all duration-300 font-bold border"
              style={{
                backgroundColor: activeCategory === cat.id ? "#c41e3a" : "transparent",
                color: activeCategory === cat.id ? "white" : "#c41e3a",
                borderColor: activeCategory === cat.id ? "#c41e3a" : "rgba(196, 30, 58, 0.5)",
              }}
            >
              <span>{cat.icon}</span>
              {cat.label}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        <div
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
          style={{
            opacity: inView ? 1 : 0,
            transition: "all 0.7s ease-out 0.3s",
          }}
        >
          {currentCategory.items.map((item, i) => (
            <div
              key={item.name}
              className="group relative overflow-hidden transition-all duration-300 hover:border-[#c41e3a] bg-[#1a1a1a] border border-[#2d2d2d]"
              style={{
                animationDelay: `${i * 0.05}s`,
              }}
            >
              {/* Image */}
              {item.img && (
                <div className="relative overflow-hidden" style={{ height: "180px" }}>
                  <img
                    src={item.img}
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                </div>
              )}

              {/* Content */}
              <div className="p-5">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h3 className="text-lg font-bold text-white">
                    {item.name}
                  </h3>
                  <span className="text-lg font-bold text-[#c41e3a] flex-shrink-0">
                    €{item.price}
                  </span>
                </div>
                <p className="text-sm text-white/70 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Red bottom accent on hover */}
              <div
                className="absolute bottom-0 left-0 h-0.5 w-0 group-hover:w-full transition-all duration-500 bg-[#c41e3a]"
              />
            </div>
          ))}
        </div>

        {/* CTA */}
        <div
          className="text-center mt-16"
          style={{
            opacity: inView ? 1 : 0,
            transition: "all 0.7s ease-out 0.5s",
          }}
        >
          <p className="text-white/70 mb-6 text-base">
            Για αναλυτικό μενού ή ειδικές παραγγελίες, επικοινώνησε μαζί μας
          </p>
          <a
            href="tel:+302492025059"
            className="inline-flex items-center gap-3 text-sm tracking-widest uppercase px-10 py-4 transition-all duration-300 bg-[#c41e3a] text-white font-bold hover:bg-[#a01830]"
          >
            📞 ΚΆΛΕΣΕ ΓΙΑ ΠΑΡΑΓΓΕΛΙΑ
          </a>
        </div>
      </div>
    </section>
  );
}
