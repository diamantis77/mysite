/**
 * PAPIGIÓN SOCIAL MEDIA BUTTONS
 * Design: Parisian Minimal Noir — floating social buttons bottom-right
 */

import { useState, useEffect } from "react";

export default function SocialMediaButtons() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 300);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const socialLinks = [
    {
      name: "Instagram",
      url: "https://instagram.com/papigion.cafe",
      icon: "📷",
      color: "#E1306C",
    },
    {
      name: "Facebook",
      url: "https://facebook.com/papigion.cafe",
      icon: "f",
      color: "#1877F2",
    },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
      {socialLinks.map((social, i) => (
        <a
          key={social.name}
          href={social.url}
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 flex items-center justify-center shadow-lg transition-all duration-500 hover:scale-110"
          style={{
            backgroundColor: social.color,
            borderRadius: "50%",
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(20px)",
            transitionDelay: `${i * 0.1}s`,
            pointerEvents: visible ? "auto" : "none",
          }}
          title={social.name}
        >
          {social.icon === "f" ? (
            <svg
              viewBox="0 0 24 24"
              fill="white"
              width="24"
              height="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
          ) : (
            <span style={{ fontSize: "1.5rem" }}>{social.icon}</span>
          )}
        </a>
      ))}
    </div>
  );
}
