/**
 * PAPIGIÓN STICKY CALL BUTTON
 * Design: Dark Premium Black & Deep Red Theme
 * Red background, fixed bottom-left call button
 */

import { useState, useEffect } from "react";
import { Phone } from "lucide-react";

export default function StickyCallButton() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 300);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <a
      href="tel:+302492025059"
      className="fixed bottom-6 left-6 z-50 flex items-center gap-3 px-6 py-4 shadow-lg transition-all duration-500 hover:opacity-90 hover:scale-105 rounded font-bold"
      style={{
        backgroundColor: "#c41e3a",
        color: "white",
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(20px)",
        pointerEvents: visible ? "auto" : "none",
      }}
    >
      <Phone size={18} />
      <span className="text-xs tracking-widest uppercase hidden sm:inline">
        ΚΆΛΕΣΕ
      </span>
    </a>
  );
}
