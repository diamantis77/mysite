/**
 * PAPIGIÓN CONTACT SECTION
 * Design: Dark Premium Black & Deep Red Theme
 * Split layout with map embed, red accents
 */

import { useEffect, useRef, useState } from "react";
import { Phone, MapPin, Clock } from "lucide-react";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const openingHours = [
  { day: "Δευτέρα", hours: "08:00 – 02:00" },
  { day: "Τρίτη", hours: "08:00 – 02:00" },
  { day: "Τετάρτη", hours: "08:00 – 02:00" },
  { day: "Πέμπτη", hours: "08:00 – 02:00" },
  { day: "Παρασκευή", hours: "08:00 – 02:00" },
  { day: "Σάββατο", hours: "09:00 – 02:00" },
  { day: "Κυριακή", hours: "09:00 – 02:00" },
];

export default function ContactSection() {
  const { ref, inView } = useInView(0.1);

  return (
    <section id="contact" className="py-24 md:py-36 overflow-hidden bg-[#0f0f0f]">
      <div className="container max-w-7xl mx-auto px-4" ref={ref}>
        {/* Header */}
        <div
          className="mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.7s ease-out",
          }}
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="h-px w-10 bg-[#c41e3a]" />
            <span className="text-xs tracking-widest uppercase text-[#c41e3a] font-bold">
              Επικοινωνία
            </span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white">
            Βρες μας στον Τύρναβο
          </h2>
        </div>

        {/* Two-column layout */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Left: Contact Info */}
          <div
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(-30px)",
              transition: "all 0.8s ease-out 0.1s",
            }}
          >
            {/* Contact cards */}
            <div className="space-y-6 mb-12">
              <a
                href="tel:+302492025059"
                className="flex items-start gap-5 p-6 group transition-all duration-300 border border-[#2d2d2d] hover:border-[#c41e3a] bg-[#1a1a1a]"
              >
                <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-[#c41e3a]/15">
                  <Phone size={18} className="text-[#c41e3a]" />
                </div>
                <div>
                  <div className="text-xs tracking-widest uppercase mb-1 text-white/60 font-bold">
                    Τηλέφωνο
                  </div>
                  <div className="text-2xl text-white group-hover:text-[#c41e3a] transition-colors font-bold">
                    +30 2492 025059
                  </div>
                </div>
              </a>

              <div className="flex items-start gap-5 p-6 border border-[#2d2d2d] bg-[#1a1a1a]">
                <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-[#c41e3a]/15">
                  <MapPin size={18} className="text-[#c41e3a]" />
                </div>
                <div>
                  <div className="text-xs tracking-widest uppercase mb-1 text-white/60 font-bold">
                    Διεύθυνση
                  </div>
                  <div className="text-2xl text-white font-bold">
                    Τύρναβος 401 00
                  </div>
                  <div className="text-sm mt-1 text-white/60">
                    Ελλάδα
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-5 p-6 border border-[#2d2d2d] bg-[#1a1a1a]">
                <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-[#c41e3a]/15">
                  <Clock size={18} className="text-[#c41e3a]" />
                </div>
                <div className="flex-1">
                  <div className="text-xs tracking-widest uppercase mb-3 text-white/60 font-bold">
                    Ώρες Λειτουργίας
                  </div>
                  <div className="space-y-2">
                    {openingHours.map((h) => (
                      <div key={h.day} className="flex justify-between items-center">
                        <span className="text-sm text-white/70">
                          {h.day}
                        </span>
                        <span className="text-xs text-[#c41e3a] font-bold">
                          {h.hours}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="tel:+302492025059"
                className="flex-1 text-center text-xs tracking-widest uppercase py-4 px-6 transition-all duration-300 bg-[#c41e3a] text-white font-bold hover:bg-[#a01830]"
              >
                📞 ΚΆΛΕΣΕ ΤΩΡΑ
              </a>
            </div>
          </div>

          {/* Right: Google Maps */}
          <div
            className="relative overflow-hidden border border-[#2d2d2d]"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(30px)",
              transition: "all 0.8s ease-out 0.25s",
              minHeight: "400px",
            }}
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3073.5!2d22.2885512!3d39.7386642!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x135861023f0f8fa7%3A0x1bc6dacaf45a1484!2sPapigi%C3%B3n!5e0!3m2!1sel!2sgr!4v1700000000000!5m2!1sel!2sgr"
              width="100%"
              height="100%"
              style={{
                border: "none",
                minHeight: "400px",
                filter: "grayscale(30%) contrast(1.1) brightness(0.9)",
              }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Papigión Location"
            />
            {/* Overlay label */}
            <div className="absolute top-4 left-4 px-4 py-2 bg-[#0f0f0f]/90 border border-[#c41e3a]">
              <span className="text-xs tracking-widest uppercase text-[#c41e3a] font-bold">
                ◆ PAPIGIÓN
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
