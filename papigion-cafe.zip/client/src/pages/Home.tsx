/**
 * PAPIGIÓN CAFE — Home Page
 * Design: "Parisian Minimal Noir"
 * Colors: Warm cream #FAF7F2, Charcoal #1C1916, Gold #C8962E, Taupe #8B7355
 * Typography: Cormorant Garamond (display) + Lato (body) + Montserrat (labels)
 */

import { useEffect, useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import GallerySection from "@/components/GallerySection";
import MenuSection from "@/components/MenuSection";
import QuoteSection from "@/components/QuoteSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import StickyCallButton from "@/components/StickyCallButton";


export default function Home() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white">
      <Navbar scrolled={scrolled} />
      <main>
        <HeroSection />
        <AboutSection />
        <GallerySection />
        <QuoteSection />
        <MenuSection />
        <ContactSection />
      </main>
      <Footer />
      <StickyCallButton />
    </div>
  );
}
